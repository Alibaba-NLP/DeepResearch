import redis
import redis.asyncio as async_redis
import hashlib
import asyncio
from datetime import timedelta
import os


host = os.getenv('redis_host','r-2ze5ea35jlh5ybt343.redis.rds.aliyuncs.com')
port = os.getenv('redis_port',6379)


pool = redis.ConnectionPool(
            host=host,
            port=int(port),
            password='',
            db=0,
            max_connections=600
)
# 全局共享的 Redis 实例
redis_client = redis.Redis(connection_pool=pool)


# 创建异步连接池
async_redis_client = async_redis.Redis(
    host=host,
    port=int(port),
    password='',
    db=0,
    max_connections=600
)


async def async_store_dictionary_with_expire(key, data_str, time_util=None, use_server=None):
    """存储字典到Redis并设置过期时间"""
    if not use_server:
        use_server = async_redis_client
    try:
        if time_util:
            await use_server.set(key, data_str, ex=timedelta(hours=time_util))
        else:
            await use_server.set(key, data_str, ex=timedelta(days=10))
        return True
    except Exception as e:
        print(f"存储失败: {str(e)}")
        return False




async def async_get_dictionary_data(key, use_server=None):
    """从Redis获取字典数据"""
    if not use_server:
        use_server = async_redis_client
    try:
        data = await use_server.get(key)
        return data if data else None
    except Exception as e:
        print(f"获取失败: {str(e)}")
        raise


def store_dictionary_with_expire(key, data_str, time_util=None, use_server=None):
    """存储字典到Redis并设置过期时间"""
    if not use_server:
        use_server = redis_client
    try:
        if time_util:
            use_server.set(key, data_str, ex=timedelta(hours=time_util))
        else:
            use_server.set(key, data_str, ex=timedelta(days=10))
        return True
    except Exception as e:
        print(f"存储失败: {str(e)}")
        return False


def get_dictionary_data(key, use_server=None):
    """从Redis获取字典数据"""
    if not use_server:
        use_server = redis_client
    try:
        data = use_server.get(key)
        return data if data else None
    except Exception as e:
        print(f"获取失败: {str(e)}")
        raise



async def async_get_for_data(biz_code: str,cache_keys: list) -> str:
    input_str = biz_code + str(cache_keys)
    sha256 = hashlib.sha256(input_str.encode()).hexdigest()
    out_bytes = await async_get_dictionary_data(sha256)
    out_data = out_bytes.decode('utf-8')

    return out_data


async def async_write_data_to_redis(biz_code: str,cache_keys: list, cache_value: str,time_to_live = None) -> bool:
    input_str = biz_code + str(cache_keys)
    sha256 = hashlib.sha256(input_str.encode()).hexdigest()  
    time_secends = time_to_live / 60 /60  
    out_data = await async_store_dictionary_with_expire(sha256, cache_value, time_secends)
    return out_data



def get_for_data(biz_code: str,cache_keys: list) -> str:
    input_str = biz_code + str(cache_keys)
    sha256 = hashlib.sha256(input_str.encode()).hexdigest()


    out_bytes = get_dictionary_data(sha256)
    out_data = out_bytes.decode('utf-8')

    return out_data


def write_data_to_redis(biz_code: str,cache_keys: list, cache_value: str,time_to_live = None) -> bool:
    input_str = biz_code + str(cache_keys)
    sha256 = hashlib.sha256(input_str.encode()).hexdigest()  
    time_secends = time_to_live / 60 /60  
    out_data = store_dictionary_with_expire(sha256, cache_value, time_secends)
    return out_data





